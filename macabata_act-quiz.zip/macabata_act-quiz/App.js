import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, Button, FlatList, TouchableOpacity } from 'react-native';

export default function App() {
  const [enteredGoalText, setEnteredGoalText] = useState('');
  const [courseGoals, setCourseGoals] = useState([]);
  const [editingIndex, setEditingIndex] = useState(null);

  const goalInputHandler = (enteredText) => {
    setEnteredGoalText(enteredText);
  };

  const addGoalHandler = () => {
    if (editingIndex !== null) {
      
      const updatedGoals = [...courseGoals];
      updatedGoals[editingIndex].text = enteredGoalText;
      setCourseGoals(updatedGoals);
      setEditingIndex(null);
    } else {
     
      setCourseGoals((currentCourseGoals) => [...currentCourseGoals, { text: enteredGoalText, isVisible: true }]);
    }
    setEnteredGoalText('');
  };

  const iDeleteMo = (index) => {
    const updatedGoals = [...courseGoals];
    updatedGoals.splice(index, 1);
    setCourseGoals(updatedGoals);
  };

  const itagoMoAko = (index) => {
    const updatedGoals = [...courseGoals];
    updatedGoals[index].isVisible = !updatedGoals[index].isVisible;
    setCourseGoals(updatedGoals);
  };

  const startEditing = (index) => {
    setEnteredGoalText(courseGoals[index].text);
    setEditingIndex(index);
  };

  const getRainbowColor = (index) => {
    const colors = ['#FED9ED', '#FF407D', '#FFCAD4', '#FC819E', '#FEC7B4', '#E78895', '#FF3EA5']; 
    return { backgroundColor: colors[index % colors.length] };
  };

  return (
    <View style={styles.appContainer}>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.textInput}
          placeholder="My Goal"
          onChangeText={goalInputHandler}
          value={enteredGoalText}
        />
        <Button title={editingIndex !== null ? "Edit Goal" : "Add Goal"} onPress={addGoalHandler} />
      </View>

      <FlatList
        data={courseGoals}
        renderItem={({ item, index }) => (
          <View style={[styles.goalsContainer, getRainbowColor(index)]}>
            <Text style={styles.textF}>
              {item.isVisible ? item.text : '************'}
            </Text>
            <View style={styles.buttonsContainer}>
              <TouchableOpacity onPress={() => iDeleteMo(index)}>
                <Text style={styles.deleteButton}>X</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => itagoMoAko(index)}>
                <Text style={styles.hideButton}>
                  {item.isVisible ? 'HIDE' : 'SHOW'}
                </Text>
              </TouchableOpacity>
              {/* Added TouchableOpacity and onPress for the EDIT button */}
              <TouchableOpacity onPress={() => startEditing(index)}>
                <Text style={styles.editButton}>EDIT</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
        keyExtractor={(item, index) => index.toString()}
        alwaysBounceVertical={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  appContainer: {
    flex: 1,
    paddingTop: 55,
    paddingHorizontal: 17,
  },

  inputContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 25,
    borderBottomWidth: 5,
    borderColor: 'black',
  },

  textInput: {
    borderWidth: 1,
    width: '70%',
    marginRight: 8,
    padding: 8,
  },

  goalsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 20,
    padding: 10,
  },

  textF: {
    fontSize: 20,
  },

  buttonsContainer: {
    flexDirection: 'row',
    position: 'absolute',
    right: 10,
  },

  deleteButton: {
    color: 'black',
    fontSize: 20,
    marginLeft: 10,
  },

  hideButton: {
    color: 'blue',
    fontSize: 20,
    marginLeft: 10,
  },

  
  editButton: {
    color: 'green',
    fontSize: 20,
    marginLeft: 10,
  },
});